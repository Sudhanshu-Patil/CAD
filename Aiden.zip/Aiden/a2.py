import os
import datetime
import pickle
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Define the required scope for Google Calendar API
SCOPES = ["https://www.googleapis.com/auth/calendar"]

def authenticate_google_calendar():
    creds = None
    # Check if token.pickle exists (stores user session)
    if os.path.exists("token.pickle"):
        with open("token.pickle", "rb") as token:
            creds = pickle.load(token)

    # If credentials are invalid or expired, refresh or request new ones
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                "credentials.json", SCOPES
            )
            creds = flow.run_local_server(port=0)

        # Save the credentials for future use
        with open("token.pickle", "wb") as token:
            pickle.dump(creds, token)

    return build("calendar", "v3", credentials=creds)

def schedule_meeting():
    service = authenticate_google_calendar()

    # Meeting details
    event = {
        "summary": "Team Meeting",
        "description": "Discuss project progress",
        "start": {
            "dateTime": "2025-02-23T10:00:00",
            "timeZone": "Asia/Kolkata",
        },
        "end": {
            "dateTime": "2025-02-23T11:00:00",
            "timeZone": "Asia/Kolkata",
        },
        "attendees": [
            {"email": "example1@gmail.com"},
            {"email": "example2@gmail.com"},
        ],
        "conferenceData": {
            "createRequest": {
                "requestId": "random123",
                "conferenceSolutionKey": {"type": "hangoutsMeet"},
            }
        },
    }

    # Insert the event into the user's calendar
    event_result = service.events().insert(
        calendarId="primary", body=event, conferenceDataVersion=1
    ).execute()

    print(f"Meeting scheduled: {event_result.get('htmlLink')}")

if __name__ == "__main__":
    schedule_meeting()
