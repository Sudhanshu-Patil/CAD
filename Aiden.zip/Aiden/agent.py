import datetime
import json
import smtplib
import holidays
import requests
from email.mime.text import MIMEText
from google.oauth2 import service_account
from googleapiclient.discovery import build

# Agentic AI-Powered Employee Onboarding System
class AgenticAIOnboarding:
    def __init__(self, employees):
        self.employees = employees
        self.holidays_list = holidays.India(years=2025)  # Change country if needed
        self.calendar_service = self.authenticate_google_calendar()
        self.slack_webhook_url = "https://hooks.slack.com/services/YOUR/WEBHOOK/URL"  # Update with actual webhook

    # 🔹 Authenticate Google Calendar API
    def authenticate_google_calendar(self):
        SCOPES = ['https://www.googleapis.com/auth/calendar']
        SERVICE_ACCOUNT_FILE = 'c:/Users/Jayasairamsuji/Desktop/Aiden/credentials.json'
        creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
        return build('calendar', 'v3', credentials=creds)

    # 🔹 AI-Powered Email Automation for Document Follow-ups
    def send_email(self, to_email, subject, body):
        sender_email = "ksaimouli2429@gmail.com"
        smtp_server = "user123@gmail.com"

        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = sender_email
        msg['To'] = to_email

        with smtplib.SMTP(smtp_server, 587) as server:
            server.starttls()
            server.login("hr@company.com", "password")  # Use secure credentials
            server.sendmail(sender_email, to_email, msg.as_string())

    # 🔹 Send Slack Notifications for Onboarding Updates
    def send_slack_notification(self, message):
        data = {"text": message}
        requests.post(self.slack_webhook_url, json=data)

    # 🔹 AI Smart Meeting Scheduler (Avoids Holidays & Conflicts)
    def schedule_meeting(self, employee, meeting_type, duration=30):
        today = datetime.date.today()
        for i in range(7):  # Check next 7 days for available slots
            meeting_date = today + datetime.timedelta(days=i)
            if meeting_date.weekday() < 5 and meeting_date not in self.holidays_list:
                meeting_time = datetime.time(10, 0)  # Default: 10 AM
                start_time = datetime.datetime.combine(meeting_date, meeting_time)
                end_time = start_time + datetime.timedelta(minutes=duration)

                event = {
                    'summary': f'{meeting_type} - {employee["name"]}',
                    'location': 'Google Meet',
                    'start': {'dateTime': start_time.isoformat(), 'timeZone': 'Asia/Kolkata'},
                    'end': {'dateTime': end_time.isoformat(), 'timeZone': 'Asia/Kolkata'},
                    'attendees': [{'email': employee["email"]}],
                    'conferenceData': {
                        'createRequest': {'requestId': "unique_id", 'conferenceSolutionKey': {'type': 'hangoutsMeet'}}
                    }
                }

                event_result = self.calendar_service.events().insert(calendarId='primary', body=event, conferenceDataVersion=1).execute()
                return event_result['hangoutLink']

    # 🔹 AI-Powered Task Tracking (Detects Missing Documents)
    def check_onboarding_progress(self, employee):
        missing_documents = ["ID Proof", "Bank Details", "Signed Offer Letter"]
        pending_tasks = [doc for doc in missing_documents if employee["documents"].get(doc) is False]

        if pending_tasks:
            email_body = f"Dear {employee['name']},\n\nPlease submit the following documents:\n- " + "\n- ".join(pending_tasks)
            self.send_email(employee['email'], "Urgent: Document Submission Pending", email_body)
            self.send_slack_notification(f"Reminder: {employee['name']} has not submitted {', '.join(pending_tasks)}.")

        return pending_tasks

    # 🔹 AI-Powered Rescheduling (Handles Meeting Cancellations)
    def reschedule_meeting(self, employee, meeting_type):
        new_meeting_link = self.schedule_meeting(employee, f"Rescheduled {meeting_type}")
        self.send_email(employee['email'], "Meeting Rescheduled", f"Your new meeting link: {new_meeting_link}")
        return f"Meeting rescheduled. New link: {new_meeting_link}"

    # 🔹 AI-Driven Employee Onboarding Workflow
    def onboarding_process(self, employee):
        print(f"👋 Welcome, {employee['name']}! AI is setting up your onboarding process...")

        # AI Schedules HR Meeting
        hr_meeting_link = self.schedule_meeting(employee, "HR Introduction")
        self.send_email(employee['email'], "HR Meeting Scheduled", f"Your HR meeting is scheduled at {hr_meeting_link}")
        self.send_slack_notification(f"📅 HR Meeting scheduled for {employee['name']} at {hr_meeting_link}")

        # AI Detects Missing Documents
        pending_tasks = self.check_onboarding_progress(employee)

        return f"✅ Onboarding started for {employee['name']}. HR Meeting: {hr_meeting_link}. Pending Tasks: {', '.join(pending_tasks)}."

# 📌 Sample Employee List
employees = [
    {"name": "Alice Johnson", "email": "alice@example.com", "documents": {"ID Proof": False, "Bank Details": True, "Signed Offer Letter": False}},
    {"name": "Bob Smith", "email": "bob@example.com", "documents": {"ID Proof": True, "Bank Details": False, "Signed Offer Letter": True}}
]

# 🚀 Initialize AI-Powered Onboarding System
agentic_ai_onboarding = AgenticAIOnboarding(employees)

# 🔹 Execute AI-Driven Onboarding Workflow
for emp in employees:
    print(agentic_ai_onboarding.onboarding_process(emp))

# 🔹 AI Handles Meeting Rescheduling Example
print(agentic_ai_onboarding.reschedule_meeting(employees[0], "HR Introduction"))
