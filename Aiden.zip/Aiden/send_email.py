import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_progress_email(employee_email, employee_name, progress_report):
    sender_email = "ksaimouli068@gmail.com"
    sender_password = "jayasairamsuji"
    
    # Email Content
    subject = f"Progress Update for {employee_name}"
    body = f"""
    Hello {employee_name},

    Here is your progress update:
    {progress_report}

    Keep up the good work!

    Regards,
    HR Team
    """
    
    # Setting up the MIME
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = employee_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    
    try:
        # Establish server connection
        server = smtplib.SMTP('smtp.example.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(msg)
        server.quit()
        print(f"Email successfully sent to {ksaimouli068@gmail.com}")
    except Exception as e:
        print(f"Error sending email: {e}")

# Example usage
send_progress_email("ksaimouli2429@gmail.com", "KSM", "Heartly welcome to our Aidenai company.")
