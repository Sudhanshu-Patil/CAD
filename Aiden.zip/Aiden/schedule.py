from datetime import datetime, timedelta

# Define working hours and holidays
WORKING_HOURS_START = 9  # 9 AM
WORKING_HOURS_END = 18   # 6 PM
HOLIDAYS = {
    "2025-01-01",
"2025-01-06",
"2025-01-20",
"2025-01-26",
"2025-02-01",
"2025-02-02",
"2025-02-17",
"2025-03-17",
"2025-03-20",
"2025-03-31",
"2025-04-13",
"2025-04-18",
"2025-04-20",
"2025-04-21",
"2025-05-01",
"2025-05-08",
"2025-05-26",
"2025-06-06",
"2025-06-16",
"2025-07-04",
"2025-07-14",
"2025-08-15",
"2025-08-30",
"2025-09-01",
"2025-09-23",
"2025-10-02",
"2025-10-31",
"2025-11-01",
"2025-11-11",
"2025-11-27",
"2025-12-24",
"2025-12-25",
"2025-12-31",
"2026-01-01",
"2026-01-06",
"2026-01-19",
"2026-02-08",
"2026-02-09",
"2026-02-16",
"2026-03-17",
"2026-03-27",
"2026-03-29",
"2026-04-01",
"2026-04-13",
"2026-05-01",
"2026-05-25",
"2026-06-05",
"2026-06-06",
"2026-07-04",
"2026-07-14",
"2026-08-15",
"2026-09-07",
"2026-10-02",
"2026-10-31",
"2026-11-11",
"2026-11-26",
"2026-12-24",
"2026-12-25",
"2026-12-31",
}

# Function to check if a given date is a working day
def is_working_day(date):
    return date.weekday() < 5 and date.strftime("%Y-%m-%d") not in HOLIDAYS  # Monday-Friday, not a holiday

# Function to find the next available meeting slot
def find_meeting_slots(participants, duration_minutes):
    meeting_slots = {}  # Store meeting times for each participant
    current_time = datetime.now().replace(second=0, microsecond=0)  # Get current time
    current_time = max(current_time, current_time.replace(hour=WORKING_HOURS_START, minute=0))  # Start at 9 AM

    for participant in participants:
        while True:
            # If the current time is outside working hours, move to next working day
            if current_time.hour + (duration_minutes // 60) >= WORKING_HOURS_END or not is_working_day(current_time.date()):
                current_time += timedelta(days=1)
                current_time = current_time.replace(hour=WORKING_HOURS_START, minute=0)
                continue

            # Found a valid slot for the participant
            meeting_slots[participant] = current_time.strftime("%Y-%m-%d %H:%M")
            # Move to the next available slot after the current meeting
            current_time += timedelta(minutes=duration_minutes)
            break  # Move to the next participant

    return meeting_slots

# Get user input for meeting duration
while True:
    try:
        meeting_duration = int(input("Enter meeting duration (30, 60, or 120 minutes): "))
        if meeting_duration not in [30, 60, 120]:
            raise ValueError
        break
    except ValueError:
        print("Invalid input! Please enter 30, 60, or 120 minutes.")

# Input: List of participants
participants = ["Alice", "Bob", "Charlie", "David", "Eve"]

# Find suitable slots for each participant
meeting_schedule = find_meeting_slots(participants, meeting_duration)

# Output the scheduled meetings
print("\n📅 Meeting Schedule:")
for participant, time in meeting_schedule.items():
    print(f"👤 {participant}: {time}")
